class ExtractGraph:

    # Please add comments along with your code.
    # key is head word; value stores next word and corresponding probability.
    graph = {}

    sentences_add = "data//assign1_sentences.txt"

    def __init__(self):
        # Extract the directed weighted graph, and save to {head_word, {tail_word, probability}}
        return
